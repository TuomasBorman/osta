# osta (OSTolaskujen Analysointi)

A Python package for analysing invoices of Finnish public organizations.

[![PyPI Latest Release](https://img.shields.io/pypi/v/osta.svg)](https://pypi.org/project/osta/)
[![Package Status](https://img.shields.io/pypi/status/osta.svg)](https://pypi.org/project/osta/)
![License](https://img.shields.io/pypi/l/osta.svg)](https://github.com/TuomasBorman/osta/blob/main/LICENSE)
[![Coverage](https://codecov.io/github/TuomasBorman/osta/coverage.svg?branch=main)](https://codecov.io/gh/TuomasBorman/osta)
[![Tests](https://github.com/TuomasBorman/osta/actions/workflows/tests.yml/badge.svg)](https://github.com/TuomasBorman/osta/commits/main)
