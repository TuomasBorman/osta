# This file runs setup of package. It gets the information from
# the setup.cfg file.
from setuptools import setup

if __name__ == "__main__":
    setup()
