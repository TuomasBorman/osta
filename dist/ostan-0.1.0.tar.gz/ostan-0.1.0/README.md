# ostan (OSTolaskujen ANalysointi)

A Python package for analysing invoices of Finnish public organizations.

[![PyPI Latest Release](https://img.shields.io/pypi/v/ostan.svg)](https://pypi.org/project/ostan/)
[![Package Status](https://img.shields.io/pypi/status/ostan.svg)](https://pypi.org/project/ostan/)
![License](https://img.shields.io/pypi/l/ostan.svg)](https://github.com/TuomasBorman/ostan/blob/main/LICENSE)
[![Coverage](https://codecov.io/github/TuomasBorman/ostan/coverage.svg?branch=main)](https://codecov.io/gh/TuomasBorman/ostan)
[![Tests](https://github.com/TuomasBorman/ostan/actions/workflows/tests.yml/badge.svg)](https://github.com/TuomasBorman/ostan/commits/main)
