# ostan (OSTolaskujen ANalysointi)

A Python package for analysing invoices of Finnish public organizations.
