# osta (OSTolaskujen Analysointi)

A Python package for analysing invoices of Finnish public organizations.
